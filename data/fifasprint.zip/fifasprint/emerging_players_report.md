# Emerging Players Scouting Report

## Jamal Musiala
- Age: 20
- Club: Bayern Munich
- Country: Germany
- Position: Midfielder
- Emergence score: 97
- Watch team: Germany
- Next opponent: Côte d'Ivoire
- Next game date: 2026-06-20
- Next game city: Toronto
- Next game venue: Toronto Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Jamal Musiala a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Germany fixtures to plan travel around Jamal Musiala.

## Kylian Mbappé
- Age: 23
- Club: Paris Saint-Germain
- Country: France
- Position: Forward
- Emergence score: 93
- Watch team: France
- Next opponent: Iraq
- Next game date: 2026-06-22
- Next game city: Philadelphia
- Next game venue: Philadelphia Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Kylian Mbappé a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow France fixtures to plan travel around Kylian Mbappé.

## Jude Bellingham
- Age: 20
- Club: Real Madrid
- Country: England
- Position: Midfielder
- Emergence score: 87
- Watch team: England
- Next opponent: Croatia
- Next game date: 2026-06-17
- Next game city: Dallas
- Next game venue: Dallas Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Jude Bellingham a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow England fixtures to plan travel around Jude Bellingham.

## Nuno Mendes
- Age: 21
- Club: Paris Saint-Germain
- Country: Portugal
- Position: Defender
- Emergence score: 86
- Watch team: Portugal
- Next opponent: Uzbekistan
- Next game date: 2026-06-23
- Next game city: Houston
- Next game venue: Houston Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Nuno Mendes a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Portugal fixtures to plan travel around Nuno Mendes.

## Phil Foden
- Age: 22
- Club: Manchester City
- Country: England
- Position: Midfielder
- Emergence score: 84
- Watch team: England
- Next opponent: Croatia
- Next game date: 2026-06-17
- Next game city: Dallas
- Next game venue: Dallas Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Phil Foden a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow England fixtures to plan travel around Phil Foden.

## Alejandro Garnacho
- Age: 19
- Club: Manchester United
- Country: Argentina
- Position: Forward
- Emergence score: 81
- Watch team: Argentina
- Next opponent: Austria
- Next game date: 2026-06-22
- Next game city: Dallas
- Next game venue: Dallas Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Alejandro Garnacho a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Argentina fixtures to plan travel around Alejandro Garnacho.

## Pedri
- Age: 20
- Club: Barcelona
- Country: Spain
- Position: Midfielder
- Emergence score: 78
- Watch team: Spain
- Next opponent: Saudi Arabia
- Next game date: 2026-06-21
- Next game city: Atlanta
- Next game venue: Atlanta Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Pedri a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Spain fixtures to plan travel around Pedri.

## Xavi Simons
- Age: 20
- Club: PSV Netherlands
- Country: Netherlands
- Position: Midfielder
- Emergence score: 75
- Watch team: Netherlands
- Next opponent: Sweden
- Next game date: 2026-06-20
- Next game city: Houston
- Next game venue: Houston Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Xavi Simons a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Netherlands fixtures to plan travel around Xavi Simons.

## Gavi
- Age: 19
- Club: Barcelona
- Country: Spain
- Position: Midfielder
- Emergence score: 74
- Watch team: Spain
- Next opponent: Saudi Arabia
- Next game date: 2026-06-21
- Next game city: Atlanta
- Next game venue: Atlanta Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Gavi a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Spain fixtures to plan travel around Gavi.

## Sandro Tonali
- Age: 22
- Club: Newcastle United
- Country: Italy
- Position: Midfielder
- Emergence score: 73
- Watch team: TBD
- Next opponent: TBD
- Next game date: TBD
- Next game city: TBD
- Next game venue: TBD
- Competition: TBD
- Fixture source: none
- Why emerging:
  - Consistent minutes growth and strong progressions make Sandro Tonali a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow TBD fixtures to plan travel around Sandro Tonali.

## William Saliba
- Age: 22
- Club: Arsenal
- Country: France
- Position: Defender
- Emergence score: 68
- Watch team: France
- Next opponent: Iraq
- Next game date: 2026-06-22
- Next game city: Philadelphia
- Next game venue: Philadelphia Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make William Saliba a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow France fixtures to plan travel around William Saliba.

## Ryan Gravenberch
- Age: 21
- Club: Liverpool
- Country: Netherlands
- Position: Midfielder
- Emergence score: 58
- Watch team: Netherlands
- Next opponent: Sweden
- Next game date: 2026-06-20
- Next game city: Houston
- Next game venue: Houston Stadium
- Competition: FIFA World Cup 2026
- Fixture source: fixtures.csv
- Why emerging:
  - Consistent minutes growth and strong progressions make Ryan Gravenberch a rising talent.
- Risk factors:
  - Age, contract timing, and competition for first-team spots should be monitored.
- Watch next:
  - Follow Netherlands fixtures to plan travel around Ryan Gravenberch.
